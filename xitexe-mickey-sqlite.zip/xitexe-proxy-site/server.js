'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, 'public');
const PORT = Number(process.env.PORT || 25565);
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC_BASE = process.env.XITEXE_PUBLIC_BASE || `http://45.196.196.241:${PORT}`;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8',
  '.bin': 'application/octet-stream',
  '.zip': 'application/zip',
  '.wasm': 'application/wasm',
};

function cacheControl(ext) {
  if (ext === '.html') return 'no-cache';
  if (ext === '.js' || ext === '.css') return 'public, max-age=60';
  if (ext === '.bin' || ext === '.gz') return 'public, max-age=31536000, immutable';
  return 'public, max-age=86400';
}

function send(res, status, text, type = 'text/plain; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': type,
    'Content-Length': Buffer.byteLength(text),
    'Cache-Control': 'no-store',
  });
  res.end(text);
}

function serveFile(req, res, file, stat) {
  const ext = path.extname(file).toLowerCase();
  const isGzip = ext === '.gz';
  const type = isGzip ? 'application/gzip' : (MIME[ext] || 'application/octet-stream');

  const headers = {
    'Content-Type': type,
    'Cache-Control': cacheControl(ext),
    'X-Content-Type-Options': 'nosniff',
    'Accept-Ranges': 'bytes',
  };

  let start = 0;
  let end = stat.size - 1;
  let status = 200;

  const range = req.headers.range;
  if (range) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
    if (match) {
      const from = match[1] === '' ? null : Number(match[1]);
      const to = match[2] === '' ? null : Number(match[2]);
      if (from === null && to !== null) {
        start = Math.max(0, stat.size - to);
        end = stat.size - 1;
      } else if (from !== null && to === null) {
        start = from;
        end = stat.size - 1;
      } else if (from !== null && to !== null) {
        start = from;
        end = Math.min(to, stat.size - 1);
      }
      if (!Number.isFinite(start) || !Number.isFinite(end) || start > end || start >= stat.size) {
        res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` });
        res.end();
        return;
      }
      status = 206;
      headers['Content-Range'] = `bytes ${start}-${end}/${stat.size}`;
    }
  }

  headers['Content-Length'] = end - start + 1;

  res.writeHead(status, headers);
  if (req.method === 'HEAD') {
    res.end();
    return;
  }

  const stream = fs.createReadStream(file, { start, end });
  stream.on('error', () => res.destroy());
  stream.pipe(res);
}

const server = http.createServer((req, res) => {
  const started = Date.now();
  if (process.env.LOG) console.log(`REQ ${req.method} ${req.url}`);
  res.on('close', () => { if (process.env.LOG && !res.writableFinished) console.log(`ABORT ${req.method} ${req.url}`); });
  res.on('finish', () => { if (process.env.LOG) console.log(`${req.method} ${req.url} ${res.statusCode} ${Date.now() - started}ms`); });
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.setHeader('Allow', 'GET, HEAD');
    send(res, 405, 'Method Not Allowed');
    return;
  }

  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  } catch {
    send(res, 400, 'Bad Request');
    return;
  }

  if (pathname === '/health') {
    send(res, 200, JSON.stringify({ ok: true, uptime: process.uptime() }), 'application/json; charset=utf-8');
    return;
  }

  if (pathname.endsWith('/')) pathname += 'index.html';

  const rel = pathname.replace(/^\/+/, '');
  const target = path.resolve(ROOT, rel);
  if (target !== ROOT && !target.startsWith(ROOT + path.sep)) {
    send(res, 403, 'Forbidden');
    return;
  }

  fs.stat(target, (err, stat) => {
    if (!err && stat.isFile()) {
      serveFile(req, res, target, stat);
      return;
    }

    if (!path.extname(pathname)) {
      const index = path.join(ROOT, 'index.html');
      fs.stat(index, (indexErr, indexStat) => {
        if (indexErr) {
          send(res, 404, 'Not Found');
          return;
        }
        serveFile(req, res, index, indexStat);
      });
      return;
    }

    send(res, 404, 'Not Found');
  });
});

server.on('clientError', (err, socket) => {
  if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
});

server.listen(PORT, HOST, () => {
  console.log(`XITEXE OFC running at ${PUBLIC_BASE}`);
  console.log(`Serving ${ROOT}`);
});

function shutdown(signal) {
  console.log(`\n${signal} received, shutting down.`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 8000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
