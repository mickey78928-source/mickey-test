'use strict';

const $ = (selector) => document.querySelector(selector);
let adminToken = '';
let regions = [];

function setStatus(text, tone = '') {
  const node = $('#status');
  node.textContent = text;
  node.className = 'pill' + (tone ? ' ' + tone : '');
}

function setHint(selector, text, tone = '') {
  const node = $(selector);
  node.textContent = text;
  node.className = 'hint' + (tone ? ' ' + tone : '');
}

function regionLabel(id) {
  if (id === 'all') return 'All regions';
  const region = regions.find((item) => item.id === id);
  return region ? region.name : id;
}

async function request(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (adminToken) headers['X-Admin-Token'] = adminToken;
  const response = await fetch(path, {
    credentials: 'same-origin',
    ...options,
    headers: { ...headers, ...(options.headers || {}) },
  });
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  if (!response.ok) {
    if (response.status === 401 && data.code === 'ADMIN_AUTH') {
      adminToken = '';
      showLogin('Admin session expired. Unlock again.');
    }
    throw new Error(data.message || `Request failed (${response.status})`);
  }
  return data;
}

function isExpired(value) {
  if (!value) return false;
  const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
  return value <= now;
}

function formatTime(value) {
  if (!value) return 'never';
  return value.replace('T', ' ');
}

function renderStats(data) {
  $('#statKeys').textContent = data.keys_total ?? 0;
  $('#statActive').textContent = data.keys_active ?? 0;
  $('#statSessions').textContent = data.sessions ?? 0;
  $('#statConnected').textContent = data.connected ?? 0;
}

function actionButton(label, className, handler) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = className;
  button.textContent = label;
  button.addEventListener('click', handler);
  return button;
}

function renderKeys(keys) {
  const body = $('#keyRows');
  body.replaceChildren();
  if (!keys.length) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 6;
    cell.className = 'table-empty';
    cell.textContent = 'No keys yet.';
    row.append(cell);
    body.append(row);
    setHint('#poolHint', 'Add the first Drip key to make the tunnel available.');
    return;
  }
  setHint('#poolHint', `${keys.length} key${keys.length === 1 ? '' : 's'} in the pool.`);
  for (const key of keys) {
    const row = document.createElement('tr');

    const keyCell = document.createElement('td');
    const code = document.createElement('code');
    code.textContent = key.key_masked;
    keyCell.append(code);

    const regionCell = document.createElement('td');
    regionCell.textContent = regionLabel(key.region);

    const hostCell = document.createElement('td');
    const host = document.createElement('code');
    host.textContent = key.host || 'auto';
    hostCell.append(host);

    const statusCell = document.createElement('td');
    const expired = isExpired(key.expires_at);
    const active = key.active && !expired;
    statusCell.textContent = expired ? 'expired' : key.active ? 'active' : 'disabled';
    statusCell.className = active ? 'status-on' : 'status-off';

    const usedCell = document.createElement('td');
    usedCell.textContent = formatTime(key.last_used_at);

    const actionsCell = document.createElement('td');
    const actions = document.createElement('div');
    actions.className = 'table-actions';
    actions.append(
      actionButton(key.active ? 'off' : 'on', 'secondary', async () => {
        await toggleKey(key.id, !key.active);
      }),
      actionButton('del', 'danger', async () => {
        await deleteKey(key.id);
      }),
    );
    actionsCell.append(actions);

    row.append(keyCell, regionCell, hostCell, statusCell, usedCell, actionsCell);
    body.append(row);
  }
}

function renderRegions() {
  const body = $('#regionRows');
  body.replaceChildren();
  if (!regions.length) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 5;
    cell.className = 'table-empty';
    cell.textContent = 'No servers yet.';
    row.append(cell);
    body.append(row);
    return;
  }
  for (const region of regions) {
    const row = document.createElement('tr');

    const idCell = document.createElement('td');
    const idCode = document.createElement('code');
    idCode.textContent = region.id;
    idCell.append(idCode);

    const nameCell = document.createElement('td');
    nameCell.textContent = region.name;

    const hostCell = document.createElement('td');
    const hostCode = document.createElement('code');
    hostCode.textContent = region.host || 'auto';
    hostCell.append(hostCode);

    const statusCell = document.createElement('td');
    statusCell.textContent = region.active ? 'active' : 'off';
    statusCell.className = region.active ? 'status-on' : 'status-off';

    const actionsCell = document.createElement('td');
    const actions = document.createElement('div');
    actions.className = 'table-actions';
    actions.append(
      actionButton('edit', 'secondary', () => editRegion(region)),
      actionButton(region.active ? 'off' : 'on', 'secondary', async () => {
        await toggleRegion(region);
      }),
    );
    actionsCell.append(actions);

    row.append(idCell, nameCell, hostCell, statusCell, actionsCell);
    body.append(row);
  }
}

function renderRegionOptions() {
  const select = $('#keyRegion');
  const current = select.value;
  select.replaceChildren();
  select.add(new Option('All regions', 'all'));
  for (const region of regions) {
    const label = region.active ? region.name : `${region.name} (off)`;
    select.add(new Option(label, region.id));
  }
  const exists = Array.from(select.options).some((option) => option.value === current);
  select.value = exists ? current : 'all';
}

function editRegion(region) {
  $('#regionId').value = region.id;
  $('#regionId').readOnly = true;
  $('#regionName').value = region.name;
  $('#regionHost').value = region.host || '';
  $('#regionActive').checked = region.active;
  setHint('#regionFormHint', `Editing ${region.id}.`, 'ok');
  $('#regionForm').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function resetRegionForm() {
  $('#regionForm').reset();
  $('#regionId').readOnly = false;
  $('#regionActive').checked = true;
  setHint('#regionFormHint', 'New server. ID is the client-facing code.');
}

async function loadRegions() {
  const data = await request('/admin/api/regions');
  regions = data.regions || [];
  renderRegions();
  renderRegionOptions();
}

async function loadKeys() {
  const data = await request('/admin/api/keys');
  renderKeys(data.keys || []);
}

async function loadStats() {
  const data = await request('/admin/api/stats');
  renderStats(data);
}

async function loadAll() {
  setStatus('loading', 'warn');
  try {
    await loadRegions();
    await Promise.all([loadKeys(), loadStats()]);
    setStatus('pool live', 'ok');
  } catch (error) {
    setStatus('error', 'err');
    setHint('#poolHint', error.message, 'err');
  }
}

async function addKey(event) {
  event.preventDefault();
  const key = $('#keyValue').value.trim();
  if (!key) return;
  const submit = event.submitter;
  if (submit) submit.disabled = true;
  setHint('#keyHint', 'Saving key...');
  try {
    await request('/admin/api/keys', {
      method: 'POST',
      body: JSON.stringify({
        key,
        label: $('#keyLabel').value.trim(),
        region: $('#keyRegion').value,
        host: $('#keyHost').value.trim(),
        expires_at: $('#keyExpires').value,
      }),
    });
    $('#keyForm').reset();
    setHint('#keyHint', 'Key added to the pool.', 'ok');
    await loadAll();
  } catch (error) {
    setHint('#keyHint', error.message, 'err');
  } finally {
    if (submit) submit.disabled = false;
  }
}

async function saveRegion(event) {
  event.preventDefault();
  const id = $('#regionId').value.trim().toLowerCase();
  const name = $('#regionName').value.trim();
  if (!id || !name) return;
  const submit = event.submitter;
  if (submit) submit.disabled = true;
  setHint('#regionFormHint', 'Saving server...');
  try {
    await request('/admin/api/regions', {
      method: 'POST',
      body: JSON.stringify({
        id,
        name,
        host: $('#regionHost').value.trim(),
        active: $('#regionActive').checked,
      }),
    });
    setHint('#regionFormHint', `Saved ${id}.`, 'ok');
    resetRegionForm();
    await loadAll();
  } catch (error) {
    setHint('#regionFormHint', error.message, 'err');
  } finally {
    if (submit) submit.disabled = false;
  }
}

async function toggleRegion(region) {
  try {
    await request('/admin/api/regions', {
      method: 'POST',
      body: JSON.stringify({
        id: region.id,
        name: region.name,
        host: region.host,
        active: !region.active,
      }),
    });
    await loadAll();
  } catch (error) {
    setHint('#regionHint', error.message, 'err');
  }
}

async function toggleKey(id, active) {
  try {
    await request('/admin/api/keys/toggle', {
      method: 'POST',
      body: JSON.stringify({ id, active }),
    });
    await loadAll();
  } catch (error) {
    setHint('#poolHint', error.message, 'err');
  }
}

async function deleteKey(id) {
  if (!confirm('Delete this Drip key from the pool?')) return;
  try {
    await request('/admin/api/keys/delete', {
      method: 'POST',
      body: JSON.stringify({ id }),
    });
    await loadAll();
  } catch (error) {
    setHint('#poolHint', error.message, 'err');
  }
}

function showLogin(message = '') {
  $('#loginCard').hidden = false;
  $('#dash').hidden = true;
  setStatus('locked', 'warn');
  if (message) setHint('#loginHint', message, 'err');
}

async function login() {
  const password = $('#adminPassword').value;
  setHint('#loginHint', 'Checking...');
  try {
    const data = await request('/admin/api/login', {
      method: 'POST',
      body: JSON.stringify({ password }),
    });
    adminToken = data.token || '';
    if (!adminToken) throw new Error('Admin token missing.');
    $('#loginCard').hidden = true;
    $('#dash').hidden = false;
    $('#adminPassword').value = '';
    setHint('#loginHint', '');
    await loadAll();
  } catch (error) {
    setHint('#loginHint', error.message, 'err');
  }
}

async function logout() {
  try {
    await request('/admin/api/logout', { method: 'POST' });
  } catch {
    // Token is already dead or the server is unreachable.
  }
  adminToken = '';
  location.reload();
}

async function start() {
  try {
    const session = await request('/admin/api/session');
    if (!session.authed) {
      showLogin(session.locked ? 'Admin is locked on the server.' : '');
      return;
    }
    $('#loginCard').hidden = true;
    $('#dash').hidden = false;
    await loadAll();
  } catch (error) {
    setStatus('error', 'err');
    setHint('#loginHint', error.message, 'err');
  }
}

$('#keyForm').addEventListener('submit', addKey);
$('#regionForm').addEventListener('submit', saveRegion);
$('#regionNewBtn').addEventListener('click', resetRegionForm);
$('#regionRefreshBtn').addEventListener('click', loadAll);
$('#loginBtn').addEventListener('click', login);
$('#logoutBtn').addEventListener('click', logout);
$('#refreshBtn').addEventListener('click', loadAll);
$('#adminPassword').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') login();
});

start();
