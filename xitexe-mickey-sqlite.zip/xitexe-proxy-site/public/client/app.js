'use strict';

const $ = (selector, root = document) => root.querySelector(selector);

const FUNCTIONS = [
  ['esp_moco', 'ESP Moco'],
  ['icewall', 'Inverted Ice'],
  ['aimbot', 'Aimbot'],
];

const DEFAULT_SETTINGS = Object.fromEntries(
  FUNCTIONS.map(([key]) => [key, true]),
);

const state = {
  server: null,
  subscription: null,
  settings: { ...DEFAULT_SETTINGS },
  servers: [],
  licenseKey: '',
  keyExpiresUnix: 0,
  timerId: null,
};

function randomHex(bytes = 8) {
  const data = new Uint8Array(bytes);
  crypto.getRandomValues(data);
  return Array.from(data, (value) => value.toString(16).padStart(2, '0')).join('').toUpperCase();
}

function makeDeviceId() {
  if (crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (char) => {
    const value = Math.floor(Math.random() * 16);
    const digit = char === 'x' ? value : (value & 0x3) | 0x8;
    return digit.toString(16);
  });
}

function readLocal() {
  try {
    return JSON.parse(localStorage.getItem('xitexe-client-v2') || '{}');
  } catch {
    return {};
  }
}

function writeLocal() {
  localStorage.setItem('xitexe-client-v2', JSON.stringify(state.settings));
}

function setStatus(text, tone = '') {
  const node = $('#status');
  node.textContent = text;
  node.className = 'pill' + (tone ? ' ' + tone : '');
}

function setHint(selector, text, tone = '') {
  const node = $(selector);
  node.textContent = text;
  node.className = 'hint' + (tone ? ' ' + tone : '');
}

function parseUtc(value) {
  if (!value) return 0;
  const text = String(value).trim().replace(' ', 'T');
  const stamp = Date.parse(text.endsWith('Z') ? text : text + 'Z');
  return Number.isFinite(stamp) ? Math.floor(stamp / 1000) : 0;
}

function startKeyTimer(unix) {
  if (state.timerId) {
    clearInterval(state.timerId);
    state.timerId = null;
  }
  const node = $('#keyTimer');
  if (!node) return;
  if (!unix) {
    node.textContent = '—';
    node.classList.remove('expired');
    return;
  }
  const tick = () => {
    const left = unix - Math.floor(Date.now() / 1000);
    if (left <= 0) {
      node.textContent = 'expired';
      node.classList.add('expired');
      if (state.timerId) clearInterval(state.timerId);
      state.timerId = null;
      return;
    }
    const days = Math.floor(left / 86400);
    const hours = Math.floor((left % 86400) / 3600);
    const minutes = Math.floor((left % 3600) / 60);
    const seconds = left % 60;
    node.textContent = (days ? days + 'd ' : '') +
      String(hours).padStart(2, '0') + ':' +
      String(minutes).padStart(2, '0') + ':' +
      String(seconds).padStart(2, '0');
  };
  tick();
  state.timerId = setInterval(tick, 1000);
}

function renderLicense(key, unix) {
  state.licenseKey = key || '';
  state.keyExpiresUnix = unix || 0;
  const active = $('#activeKey');
  if (active) active.textContent = key || '—';
  startKeyTimer(unix);
}

async function request(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  if (!response.ok) {
    if (response.status === 401 && data.code === 'GATE_REQUIRED') {
      window.location.replace('/client/');
    }
    throw new Error(data.message || `Request failed (${response.status})`);
  }
  return data;
}

function renderServers(servers) {
  const root = $('#servers');
  root.replaceChildren();
  state.servers = Array.isArray(servers) ? servers : [];
  if (!state.servers.length) {
    const empty = document.createElement('p');
    empty.className = 'empty';
    empty.textContent = 'No regions available.';
    root.append(empty);
    return;
  }
  state.server = state.server || state.servers[0].id;
  for (const server of state.servers) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'server' + (server.id === state.server ? ' active' : '');
    button.dataset.id = server.id;
    const small = document.createElement('small');
    small.textContent = 'region // ' + server.id;
    const strong = document.createElement('strong');
    strong.textContent = server.name;
    button.append(small, strong);
    button.addEventListener('click', () => {
      state.server = server.id;
      for (const node of root.querySelectorAll('.server')) {
        node.classList.toggle('active', node.dataset.id === state.server);
      }
      $('#connectBtn').disabled = false;
    });
    root.append(button);
  }
  $('#connectBtn').disabled = false;
}

async function loadServers() {
  const license = $('#licenseKey').value.trim();
  const device = $('#deviceId').value.trim();
  setStatus('loading', 'warn');
  setHint('#sessionHint', 'Opening session...');
  $('#loadServers').disabled = true;
  try {
    const data = await request('/client/api/servers.php', {
      method: 'POST',
      body: JSON.stringify({ license_key: license, device_id: device }),
    });
    renderServers(data.servers);
    const fullKey = data.license_key || license;
    if (fullKey) $('#licenseKey').value = fullKey;
    const keyExpiry = Number(data.key_expires_unix || 0) ||
      parseUtc(data.key_expires_at) ||
      parseUtc(data.expires_at);
    renderLicense(fullKey, keyExpiry);
    setStatus('session open', 'ok');
    setHint('#sessionHint', 'License verified. Session open until ' + data.expires_at + ' UTC.');
    await loadSettings();
  } catch (error) {
    setStatus('offline', 'err');
    setHint('#sessionHint', error.message, 'err');
  } finally {
    $('#loadServers').disabled = false;
  }
}

async function connectTunnel() {
  if (!state.server) return;
  setStatus('connecting', 'warn');
  setHint('#connectHint', 'Allocating upstream key...');
  $('#connectBtn').disabled = true;
  try {
    const data = await request('/client/api/connect.php', {
      method: 'POST',
      body: JSON.stringify({ server: state.server }),
    });
    state.subscription = data.subscription_url;
    $('#linkOut').value = data.encrypted_link;
    $('#linkUpstream').textContent = 'upstream // ' + data.upstream;
    $('#linkMode').textContent = data.wrapped ? 'happ crypt5' : 'plain subscription';
    $('#openHapp').href = data.encrypted_link;
    $('#linkCard').hidden = false;
    setStatus('tunnel ready', 'ok');
    setHint('#connectHint', 'Tunnel config generated. Import it in Happ.', 'ok');
    $('#linkCard').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (error) {
    setStatus('no upstream', 'err');
    setHint('#connectHint', error.message, 'err');
  } finally {
    $('#connectBtn').disabled = false;
  }
}

function buildToggles() {
  const root = $('#functions');
  root.replaceChildren();
  for (const [key, label] of FUNCTIONS) {
    const wrapper = document.createElement('label');
    wrapper.className = 'toggle';
    const text = document.createElement('span');
    text.textContent = label;
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.dataset.key = key;
    input.checked = Boolean(state.settings[key]);
    const slider = document.createElement('span');
    slider.className = 'switch';
    wrapper.append(text, input, slider);
    root.append(wrapper);
  }
}

function readToggles() {
  const values = {};
  for (const input of document.querySelectorAll('#functions input[data-key]')) {
    values[input.dataset.key] = input.checked;
  }
  return values;
}

async function loadSettings() {
  try {
    const data = await request('/client/api/settings.php');
    if (data.settings && typeof data.settings === 'object') {
      state.settings = { ...DEFAULT_SETTINGS, ...state.settings, ...data.settings };
      for (const [key] of FUNCTIONS) state.settings[key] = true;
      buildToggles();
    }
  } catch {
    buildToggles();
  }
}

async function savePanel() {
  state.settings = readToggles();
  writeLocal();
  setHint('#panelHint', 'Saved locally.', 'ok');
  try {
    await request('/client/api/settings.php', {
      method: 'POST',
      body: JSON.stringify({ settings: state.settings }),
    });
    setHint('#panelHint', 'Panel saved to this session.', 'ok');
  } catch (error) {
    setHint('#panelHint', error.message, 'err');
  }
}

async function copyText(value, button) {
  try {
    await navigator.clipboard.writeText(value);
    const old = button.textContent;
    button.textContent = 'Copied';
    setTimeout(() => { button.textContent = old; }, 1200);
  } catch {
    const area = document.createElement('textarea');
    area.value = value;
    document.body.append(area);
    area.select();
    document.execCommand('copy');
    area.remove();
  }
}

function openPromo() {
  const modal = $('#promoModal');
  if (!modal) return;
  modal.hidden = false;
  document.body.classList.add('promo-open');
  requestAnimationFrame(() => modal.classList.add('open'));
  const close = $('.promo-close', modal);
  if (close) close.focus();
}

function closePromo() {
  const modal = $('#promoModal');
  if (!modal) return;
  modal.classList.remove('open');
  document.body.classList.remove('promo-open');
  setTimeout(() => { modal.hidden = true; }, 180);
}

function initPromo() {
  const modal = $('#promoModal');
  if (!modal) return;
  let afterGate = false;
  try {
    afterGate = sessionStorage.getItem('xitexe-promo-gate') === '1';
    if (afterGate) sessionStorage.removeItem('xitexe-promo-gate');
  } catch (error) {}
  if (!afterGate) setTimeout(openPromo, 450);
  modal.querySelectorAll('[data-promo-close]').forEach((node) => {
    node.addEventListener('click', closePromo);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !modal.hidden) closePromo();
  });
}

function bind() {
  $('#loadServers').addEventListener('click', loadServers);
  $('#connectBtn').addEventListener('click', connectTunnel);
  $('#savePanel').addEventListener('click', savePanel);
  $('#copyLink').addEventListener('click', () => {
    copyText($('#linkOut').value, $('#copyLink'));
  });
  $('#copySub').addEventListener('click', () => {
    copyText(state.subscription || '', $('#copySub'));
  });
  $('#licenseKey').addEventListener('change', () => {
    localStorage.setItem('xitexe-license', $('#licenseKey').value.trim());
  });
}

function init() {
  const saved = readLocal();
  state.settings = { ...DEFAULT_SETTINGS, ...(saved && typeof saved === 'object' ? saved : {}) };
  for (const [key] of FUNCTIONS) state.settings[key] = true;
  const license = localStorage.getItem('xitexe-license') || 'XITEXE-' + randomHex(4);
  let device = localStorage.getItem('xitexe-device');
  if (!device) {
    device = makeDeviceId();
    localStorage.setItem('xitexe-device', device);
  }
  $('#licenseKey').value = license;
  $('#deviceId').value = device;
  renderLicense(license, 0);
  buildToggles();
  bind();
  initPromo();
  loadServers();
}

init();
