/* MICKEY panel database adapter: Firestore-style API over Python + SQLite. */
(() => {
  const API='/mickey/api/';
  const stamp=()=>({__type:'serverTimestamp'});
  const headers=()=>{
    const h={'Content-Type':'application/json'};
    const a=localStorage.getItem('mw_admin_token'); if(a) h['X-Admin-Token']=a;
    const k=localStorage.getItem('mw_client_key'); if(k) h['X-Client-Key']=k;
    return h;
  };
  async function call(method,url,body){
    const r=await fetch(url,{method,credentials:'same-origin',headers:headers(),body:body?JSON.stringify(body):undefined});
    const d=await r.json().catch(()=>({})); if(!r.ok) throw new Error(d.error||d.message||`HTTP ${r.status}`); return d;
  }
  const ts=(v)=>v&&typeof v==='object'&&Number.isFinite(v.seconds)?v:{seconds:Math.floor(new Date(v).getTime()/1000)};
  class Snap { constructor(id,data,exists=true,ref=null){this.id=id;this._data=data||{};this.exists=exists;this.ref=ref;} data(){return this._data;} }
  class DocRef {
    constructor(col,id){this.col=col;this.id=id;}
    async get(){const d=await call('GET',API+encodeURIComponent(this.col)+'/'+encodeURIComponent(this.id));return new Snap(this.id,d.data,d.exists,this);}
    async update(data){return call('POST',API+encodeURIComponent(this.col)+'/'+encodeURIComponent(this.id),{action:'update',data});}
    async set(data,opt={}){return call('POST',API+encodeURIComponent(this.col)+'/'+encodeURIComponent(this.id),{action:'set',data,merge:!!opt.merge});}
    async delete(){return call('POST',API+encodeURIComponent(this.col)+'/'+encodeURIComponent(this.id),{action:'delete'});}
    onSnapshot(cb){let stopped=false,last='';const tick=async()=>{try{const s=await this.get();const v=JSON.stringify([s.exists,s.data()]);if(v!==last){last=v;if(!stopped)cb(s);}}catch(e){console.warn('SQLite listener:',e.message);}};tick();const id=setInterval(tick,2500);return()=>{stopped=true;clearInterval(id);};}
  }
  class Query {
    constructor(col,field='',value='',max=100){this.col=col;this.field=field;this.value=value;this.max=max;}
    where(field,op,value){if(op!=='==')throw Error('Only == query supported');return new Query(this.col,field,value,this.max);}
    limit(n){return new Query(this.col,this.field,this.value,n);}
    async get(){let url=API+encodeURIComponent(this.col)+'?action='+(this.field?'query':'list');if(this.field)url+='&field='+encodeURIComponent(this.field)+'&value='+encodeURIComponent(this.value);const d=await call('GET',url);if(this.field==='key'&&d.docs?.[0])localStorage.setItem('mw_client_key',String(this.value).toUpperCase());const docs=(d.docs||[]).slice(0,this.max).map(x=>new Snap(x.id,x.data,true,new DocRef(this.col,x.id)));return {docs,empty:!docs.length,size:docs.length,forEach(fn){docs.forEach(fn);}};}
    onSnapshot(cb){let stopped=false,last='';const tick=async()=>{try{const s=await this.get();const v=JSON.stringify(s.docs.map(x=>[x.id,x.data()]));if(v!==last){last=v;if(!stopped)cb(s);}}catch(e){console.warn('SQLite listener:',e.message);}};tick();const id=setInterval(tick,2500);return()=>{stopped=true;clearInterval(id);};}
    async add(data){const d=await call('POST',API+encodeURIComponent(this.col),{action:'add',data});return new DocRef(this.col,d.id);}
  }
  class Batch {
    constructor(){this.jobs=[];}
    update(ref,data){this.jobs.push(()=>ref.update(data));return this;}
    delete(ref){this.jobs.push(()=>ref.delete());return this;}
    async commit(){for(const job of this.jobs)await job();}
  }
  const db={collection:name=>new Query(name),batch:()=>new Batch()};
  window.panelDB=db;
  window.panelDB.Timestamp={fromDate:d=>({seconds:Math.floor(d.getTime()/1000)})};
  window.panelDB.FieldValue={serverTimestamp:stamp,delete:()=>({__type:'delete'})};
})();
