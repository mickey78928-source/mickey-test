#!/usr/bin/env python3

import json
import os
import posixpath
import re
import signal
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = (Path(__file__).resolve().parent / "public").resolve()
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", os.environ.get("SERVER_PORT", "25565")))
PUBLIC_BASE = os.environ.get("XITEXE_PUBLIC_BASE", "https://xitofcproxy.duckdns.org")
LOG = bool(os.environ.get("LOG"))
START = time.time()

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".webp": "image/webp",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".ttf": "font/ttf",
    ".txt": "text/plain; charset=utf-8",
    ".bin": "application/octet-stream",
    ".zip": "application/zip",
    ".wasm": "application/wasm",
    ".gz": "application/gzip",
}

CHUNK = 256 * 1024
RANGE_RE = re.compile(r"^(\d*)-(\d*)$")


def cache_control(ext):
    if ext == ".html":
        return "no-cache"
    if ext in (".js", ".css"):
        return "public, max-age=60"
    if ext in (".bin", ".gz"):
        return "public, max-age=31536000, immutable"
    return "public, max-age=86400"


def parse_range(value, size):
    if not value:
        return None
    value = value.strip()
    if not value.startswith("bytes="):
        return None
    match = RANGE_RE.match(value[6:])
    if not match:
        return None
    first, last = match.groups()
    if first == "" and last == "":
        return None
    try:
        if first == "":
            suffix = int(last)
            start = max(0, size - suffix)
            end = size - 1
        elif last == "":
            start = int(first)
            end = size - 1
        else:
            start = int(first)
            end = min(int(last), size - 1)
    except ValueError:
        return None
    if start > end or start >= size:
        return "invalid"
    return start, end


def discover_ip():
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except OSError:
        return None


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "xitexe/1.0"

    def log_message(self, fmt, *args):
        if LOG:
            super().log_message(fmt, *args)

    def send_plain(self, status, text, extra=None):
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if extra:
            for key, value in extra.items():
                self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def method_not_allowed(self):
        self.send_plain(405, "Method Not Allowed", {"Allow": "GET, HEAD"})

    do_POST = method_not_allowed
    do_PUT = method_not_allowed
    do_PATCH = method_not_allowed
    do_DELETE = method_not_allowed
    do_OPTIONS = method_not_allowed

    def do_GET(self):
        self.serve()

    def do_HEAD(self):
        self.serve()

    def serve(self):
        try:
            raw_path = urlsplit(self.path).path
            pathname = unquote(raw_path)
        except (ValueError, UnicodeDecodeError):
            self.send_plain(400, "Bad Request")
            return

        if "\x00" in pathname:
            self.send_plain(400, "Bad Request")
            return

        if pathname == "/health":
            body = json.dumps(
                {"ok": True, "uptime": round(time.time() - START, 3)},
                separators=(",", ":"),
            ).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)
            return

        if pathname.endswith("/"):
            pathname += "index.html"

        rel = pathname.lstrip("/")
        try:
            target = (ROOT / rel).resolve()
        except (OSError, ValueError):
            self.send_plain(400, "Bad Request")
            return

        if target != ROOT and ROOT not in target.parents:
            self.send_plain(403, "Forbidden")
            return

        if not target.is_file():
            if not posixpath.splitext(pathname)[1]:
                index = ROOT / "index.html"
                if index.is_file():
                    target = index
                else:
                    self.send_plain(404, "Not Found")
                    return
            else:
                self.send_plain(404, "Not Found")
                return

        try:
            stat = target.stat()
        except OSError:
            self.send_plain(404, "Not Found")
            return

        ext = target.suffix.lower()
        content_type = MIME.get(ext, "application/octet-stream")
        size = stat.st_size
        byte_range = parse_range(self.headers.get("Range"), size)

        if byte_range == "invalid":
            self.send_plain(
                416,
                "Range Not Satisfiable",
                {"Content-Range": f"bytes */{size}"},
            )
            return

        if byte_range is None:
            start = 0
            end = size - 1
            status = 200
        else:
            start, end = byte_range
            status = 206

        length = max(0, end - start + 1)

        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", cache_control(ext))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Accept-Ranges", "bytes")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()

        if self.command == "HEAD" or length == 0:
            return

        try:
            with target.open("rb") as handle:
                handle.seek(start)
                remaining = length
                while remaining > 0:
                    block = handle.read(min(CHUNK, remaining))
                    if not block:
                        break
                    self.wfile.write(block)
                    remaining -= len(block)
        except (BrokenPipeError, ConnectionResetError):
            return


class Server(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    try:
        server = Server((HOST, PORT), Handler)
    except OSError as exc:
        print(f"Could not bind {HOST}:{PORT}: {exc}", file=sys.stderr)
        return 1

    def shutdown(signum, frame):
        print(f"\nSignal {signum}: shutting down.", flush=True)
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    print(f"XITEXE OFC running at {PUBLIC_BASE}", flush=True)
    print(f"Serving {ROOT}", flush=True)

    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    proxy = Path(__file__).resolve().parent / "xitexe.py"
    if proxy.exists() and os.environ.get("XITEXE_STATIC", "0") != "1":
        import xitexe
        sys.exit(xitexe.main())
    sys.exit(main())
