#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export HOST=0.0.0.0
export PORT="${SERVER_PORT:-25565}"
export XITEXE_PUBLIC_BASE="${XITEXE_PUBLIC_BASE:-https://xitofcproxy.duckdns.org}"
exec python3 xitexe.py
