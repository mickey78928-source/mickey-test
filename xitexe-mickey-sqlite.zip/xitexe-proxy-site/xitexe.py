#!/usr/bin/env python3

import hmac
import html
import json
import os
import posixpath
import re
import secrets
import signal
import sqlite3
import sys
import threading
import time
import urllib.request
import uuid
from datetime import datetime, timedelta, timezone
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

from app import HOST, PORT, Handler as StaticHandler, Server

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("XITEXE_DB", str(BASE / "xitexe.db")))
ADMIN_PASSWORD = os.environ.get("XITEXE_ADMIN_PASSWORD", "xit1009").strip()
SESSION_DAYS = int(os.environ.get("XITEXE_SESSION_DAYS", "7"))
HAPP_WRAP = os.environ.get("XITEXE_HAPP_WRAP", "1") != "0"
HAPP_API = os.environ.get("XITEXE_HAPP_API", "https://crypto.happ.su/api-v2.php")
PUBLIC_BASE = os.environ.get("XITEXE_PUBLIC_BASE", "https://xitofcproxy.duckdns.org").rstrip("/")
GATE_COOKIE = "xitexe_gate"
GATE_HOURS = max(1, int(os.environ.get("XITEXE_GATE_HOURS", "12")))
GATE_VALIDATOR_URL = os.environ.get(
    "XITEXE_GATE_VALIDATOR_URL", "https://xitexekey.duckdns.org"
).rstrip("/")
GATE_KEY_SYSTEM_URL = os.environ.get(
    "XITEXE_KEY_SYSTEM_URL", "https://xitexekey.duckdns.org"
).rstrip("/")
GATE_PAGE_FILE = BASE / "public" / "client" / "gate.html"
PROFILE = "Xitexe-Client"

DEFAULT_REGIONS = [
    ("bd", "Bangladesh"),
    ("sg", "Singapore"),
    ("ind", "India"),
    ("eu", "Europe"),
    ("br", "Brazil"),
]


def now_ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def future_ts(days):
    return (datetime.now(timezone.utc) + timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")


def open_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with open_db() as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS drip_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL UNIQUE,
                label TEXT NOT NULL DEFAULT '',
                region TEXT NOT NULL DEFAULT 'all',
                host TEXT NOT NULL DEFAULT '',
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                last_used_at TEXT,
                expires_at TEXT
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                license_key TEXT NOT NULL DEFAULT '',
                device_id TEXT NOT NULL DEFAULT '',
                gate_token TEXT NOT NULL DEFAULT '',
                server TEXT,
                drip_key_id INTEGER,
                created_at TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                expires_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS admin_sessions (
                token TEXT PRIMARY KEY,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS gate_sessions (
                token TEXT PRIMARY KEY,
                license_key TEXT NOT NULL DEFAULT '',
                key_tail TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS user_settings (
                token TEXT PRIMARY KEY,
                data TEXT NOT NULL DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS regions (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                host TEXT NOT NULL DEFAULT '',
                active INTEGER NOT NULL DEFAULT 1,
                sort_order INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS panel_docs (
                collection_name TEXT NOT NULL,
                doc_id TEXT NOT NULL,
                data TEXT NOT NULL DEFAULT '{}',
                updated_at TEXT NOT NULL,
                PRIMARY KEY (collection_name, doc_id)
            );
            """
        )
        session_columns = {
            row[1] for row in conn.execute("PRAGMA table_info(sessions)")
        }
        if "gate_token" not in session_columns:
            conn.execute(
                "ALTER TABLE sessions ADD COLUMN gate_token TEXT NOT NULL DEFAULT ''"
            )
        gate_columns = {
            row[1] for row in conn.execute("PRAGMA table_info(gate_sessions)")
        }
        if "license_key" not in gate_columns:
            conn.execute(
                "ALTER TABLE gate_sessions ADD COLUMN license_key TEXT NOT NULL DEFAULT ''"
            )
        if "key_expires_at" not in gate_columns:
            conn.execute(
                "ALTER TABLE gate_sessions ADD COLUMN key_expires_at TEXT NOT NULL DEFAULT ''"
            )
        if "key_expires_unix" not in gate_columns:
            conn.execute(
                "ALTER TABLE gate_sessions ADD COLUMN key_expires_unix INTEGER NOT NULL DEFAULT 0"
            )
        for index, (region_id, region_name) in enumerate(DEFAULT_REGIONS):
            conn.execute(
                "INSERT OR IGNORE INTO regions (id, name, active, sort_order) "
                "VALUES (?, ?, 1, ?)",
                (region_id, region_name, index),
            )
    try:
        os.chmod(DB_PATH, 0o600)
    except OSError:
        pass


def mask_key(value):
    value = str(value or "")
    if len(value) <= 4:
        return "*" * len(value)
    return f"{value[:2]}{'*' * max(4, len(value) - 4)}{value[-2:]}"


def normalize_expiry(value):
    text = str(value or "").strip()
    if not text:
        return None
    text = text.replace("T", " ")
    if len(text) == 16:
        text += ":00"
    return text


def load_regions(include_inactive=False):
    query = "SELECT id, name, host, active FROM regions"
    if not include_inactive:
        query += " WHERE active = 1"
    query += " ORDER BY sort_order, id"
    with open_db() as conn:
        rows = conn.execute(query).fetchall()
    return [
        {
            "id": row["id"],
            "name": row["name"],
            "host": row["host"],
            "active": bool(row["active"]),
        }
        for row in rows
    ]


def region_ids(include_inactive=False):
    return {item["id"] for item in load_regions(include_inactive)}


def region_exists(region_id):
    with open_db() as conn:
        row = conn.execute(
            "SELECT 1 FROM regions WHERE id = ?", (region_id,)
        ).fetchone()
    return row is not None


def resolve_host(region_id, host_override=""):
    host = str(host_override or "").strip()
    if host:
        return host
    with open_db() as conn:
        row = conn.execute(
            "SELECT host FROM regions WHERE id = ?", (region_id,)
        ).fetchone()
    if row and str(row["host"] or "").strip():
        return str(row["host"]).strip()
    return f"proxy-{region_id}.dripwire.cc"


def happ_wrap(url):
    if not HAPP_WRAP or not url.startswith("http"):
        return None
    if "127.0.0.1" in url or "localhost" in url:
        return None
    payload = json.dumps({"url": url}).encode("utf-8")
    request = urllib.request.Request(
        HAPP_API,
        data=payload,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Xitexe/1.0",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=6) as response:
            data = json.loads(response.read().decode("utf-8", "replace"))
    except Exception:
        return None
    if isinstance(data, str) and data.startswith("happ://"):
        return data
    if isinstance(data, dict):
        for key in ("url", "link", "encrypted_link", "data", "result"):
            value = data.get(key)
            if isinstance(value, str) and value.startswith("happ://"):
                return value
            if isinstance(value, dict):
                for nested in ("url", "link"):
                    inner = value.get(nested)
                    if isinstance(inner, str) and inner.startswith("happ://"):
                        return inner
    return None


class Handler(StaticHandler):
    def do_POST(self):
        path = urlsplit(self.path).path
        if path == "/client/gate":
            return self.handle_gate_post()
        if path.startswith("/admin/api/"):
            return self.handle_admin(path, "POST")
        if path.startswith("/client/api/"):
            return self.handle_client(path, "POST")
        if path.startswith("/mickey/api/"):
            return self.handle_panel_db(path, "POST")
        self.method_not_allowed()

    def serve(self):
        path = urlsplit(self.path).path
        if path == "/":
            self.redirect("/client/")
            return
        if path in ("/admin", "/client"):
            self.redirect(f"{path}/")
            return
        if path.startswith("/admin/api/"):
            return self.handle_admin(path, "GET")
        if path.startswith("/client/api/"):
            return self.handle_client(path, "GET")
        if path.startswith("/mickey/api/"):
            return self.handle_panel_db(path, "GET")
        if path == "/client/subscription.php":
            return self.handle_subscription()
        super().serve()

    def redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def send_json(self, status, payload, cookies=None):
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if cookies:
            for cookie in cookies:
                self.send_header("Set-Cookie", cookie)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def read_json(self):
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            return None
        if length < 0 or length > 1_000_000:
            return None
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None
        return data if isinstance(data, dict) else None

    def cookie(self, name):
        raw = self.headers.get("Cookie")
        if not raw:
            return None
        jar = SimpleCookie()
        try:
            jar.load(raw)
        except Exception:
            return None
        morsel = jar.get(name)
        return morsel.value if morsel else None

    def is_secure(self):
        proto = self.headers.get("X-Forwarded-Proto", "").split(",")[0].strip().lower()
        return proto == "https" or self.headers.get("X-Forwarded-Ssl") == "on"

    def cookie_header(self, name, value, max_age):
        parts = [
            f"{name}={value}",
            "Path=/",
            "HttpOnly",
            "SameSite=Lax",
            f"Max-Age={max_age}",
        ]
        if self.is_secure():
            parts.append("Secure")
        return "; ".join(parts)

    def clear_cookie(self, name):
        return self.cookie_header(name, "", 0)

    def send_html(self, status, text, extra=None):
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if extra:
            for key, value in extra.items():
                self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def gate_error_block(self, error):
        if not error:
            return ""
        return (
            '<div class="gate-error" role="alert" aria-live="polite">'
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" '
            'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
            '<path d="M12 9v4"/><path d="M12 17h.01"/>'
            '<path d="M10.3 3.7 2.4 18a2 2 0 0 0 1.8 3h15.6a2 2 0 0 0 1.8-3L13.7 3.7a2 2 0 0 0-3.4 0Z"/>'
            "</svg>"
            f"<span>{html.escape(error)}</span>"
            "</div>"
        )

    def render_gate(self, error=""):
        try:
            page = GATE_PAGE_FILE.read_text(encoding="utf-8")
        except OSError:
            return "<!doctype html><title>Gate unavailable</title><h1>Gate unavailable</h1>"
        page = page.replace("<!--GATE_ERROR-->", self.gate_error_block(error))
        page = page.replace(
            "https://xitexekey.duckdns.org/admin", GATE_KEY_SYSTEM_URL + "/admin"
        )
        page = page.replace("https://xitexekey.duckdns.org", GATE_KEY_SYSTEM_URL)
        return page

    def drop_gate_session(self, token):
        with open_db() as conn:
            conn.execute(
                "DELETE FROM user_settings WHERE token IN "
                "(SELECT token FROM sessions WHERE gate_token = ?)",
                (token,),
            )
            conn.execute("DELETE FROM sessions WHERE gate_token = ?", (token,))
            conn.execute("DELETE FROM gate_sessions WHERE token = ?", (token,))

    def gate_session(self):
        token = self.cookie(GATE_COOKIE)
        if not token:
            return None
        with open_db() as conn:
            row = conn.execute(
                "SELECT * FROM gate_sessions WHERE token = ?", (token,)
            ).fetchone()
            if (
                row is None
                or row["expires_at"] <= now_ts()
                or not str(row["license_key"] or "").strip()
            ):
                self.drop_gate_session(token)
                return None
        valid, _, _ = self.remote_gate_check(row["license_key"])
        if valid is not True:
            self.drop_gate_session(token)
            return None
        return row

    def gate_authed(self):
        return self.gate_session() is not None

    def remote_gate_check(self, value, device_id=""):
        payload_out = {
            "action": "login" if device_id else "check",
            "key": value,
        }
        if device_id:
            payload_out["device_id"] = device_id
        body = json.dumps(payload_out).encode("utf-8")
        request = urllib.request.Request(
            GATE_VALIDATOR_URL + "/api.php",
            data=body,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "XITEXE-Gate/1.0",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                payload = json.loads(response.read().decode("utf-8") or "{}")
        except Exception:
            return None, "Key server is unreachable. Try again.", {}
        if not isinstance(payload, dict):
            return None, "Key server returned an invalid response. Try again.", {}
        if payload.get("valid") is True or payload.get("success") is True:
            expiry_text = normalize_expiry(
                payload.get("expires_at")
                or payload.get("expire")
                or payload.get("keyExpiresAt")
                or ""
            ) or ""
            try:
                expiry_unix = int(payload.get("expires_unix") or payload.get("exp") or 0)
            except (TypeError, ValueError):
                expiry_unix = 0
            return True, "", {
                "key": str(payload.get("key") or value).strip(),
                "expires_at": expiry_text,
                "expires_unix": expiry_unix,
            }
        return False, "Key not recognized or expired on the key server.", {}

    def handle_gate_post(self):
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 100_000:
            return self.send_html(400, self.render_gate("Enter your license key to continue."))
        raw = self.rfile.read(length)
        try:
            form = parse_qs(raw.decode("utf-8"))
        except UnicodeDecodeError:
            form = {}
        value = (form.get("key") or [""])[0].strip()
        device_id = (form.get("device_id") or [""])[0].strip()[:128]
        if not value:
            return self.send_html(200, self.render_gate("Enter your license key to continue."))
        if len(value) > 120:
            return self.send_html(200, self.render_gate("That license key is not valid."))
        valid, reason, meta = self.remote_gate_check(value, device_id)
        if valid is not True:
            return self.send_html(
                200,
                self.render_gate(reason or "Key not recognized or expired on the key server."),
            )
        token = secrets.token_hex(32)
        expires_at = (
            datetime.now(timezone.utc) + timedelta(hours=GATE_HOURS)
        ).strftime("%Y-%m-%d %H:%M:%S")
        full_key = str(meta.get("key") or value).strip()
        key_expires_at = str(meta.get("expires_at") or "")
        key_expires_unix = int(meta.get("expires_unix") or 0)
        with open_db() as conn:
            conn.execute(
                "INSERT INTO gate_sessions "
                "(token, license_key, key_tail, created_at, expires_at, key_expires_at, key_expires_unix) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (token, full_key, full_key[-4:], now_ts(), expires_at, key_expires_at, key_expires_unix),
            )
            conn.execute("DELETE FROM gate_sessions WHERE expires_at <= ?", (now_ts(),))
        self.send_response(302)
        self.send_header("Location", "/client/")
        self.send_header(
            "Set-Cookie", self.cookie_header(GATE_COOKIE, token, GATE_HOURS * 3600)
        )
        self.send_header("Content-Length", "0")
        self.end_headers()

    def admin_authed(self):
        if not ADMIN_PASSWORD:
            return False
        token = str(self.headers.get("X-Admin-Token", "") or "").strip()
        if not token:
            return False
        with open_db() as conn:
            row = conn.execute(
                "SELECT created_at FROM admin_sessions WHERE token = ?", (token,)
            ).fetchone()
            if row is None:
                return False
            if row["created_at"] < future_ts(-1):
                conn.execute("DELETE FROM admin_sessions WHERE token = ?", (token,))
                return False
        return True

    def require_admin(self):
        if self.admin_authed():
            return True
        self.send_json(401, {"status": "error", "code": "ADMIN_AUTH", "message": "Admin login required."})
        return False

    def handle_admin(self, path, method):
        if path == "/admin/api/session" and method == "GET":
            self.send_json(
                200,
                {"authed": self.admin_authed(), "locked": not ADMIN_PASSWORD},
            )
            return

        if path == "/admin/api/login" and method == "POST":
            data = self.read_json()
            if data is None:
                self.send_json(400, {"status": "error", "message": "Invalid JSON."})
                return
            if not ADMIN_PASSWORD:
                self.send_json(
                    503,
                    {"status": "error", "message": "Admin is locked on the server."},
                )
                return
            supplied = str(data.get("password", ""))
            if not hmac.compare_digest(supplied, ADMIN_PASSWORD):
                self.send_json(401, {"status": "error", "message": "Wrong admin password."})
                return
            token = secrets.token_hex(32)
            cutoff = future_ts(-1)
            with open_db() as conn:
                conn.execute(
                    "INSERT INTO admin_sessions (token, created_at) VALUES (?, ?)",
                    (token, now_ts()),
                )
                conn.execute(
                    "DELETE FROM admin_sessions WHERE created_at < ?", (cutoff,)
                )
            self.send_json(200, {"status": "success", "token": token})
            return

        if path == "/admin/api/logout" and method == "POST":
            token = str(self.headers.get("X-Admin-Token", "") or "").strip()
            if token:
                with open_db() as conn:
                    conn.execute(
                        "DELETE FROM admin_sessions WHERE token = ?", (token,)
                    )
            self.send_json(200, {"status": "success"})
            return

        if path == "/admin/api/regions" and method == "GET":
            if not self.require_admin():
                return
            self.send_json(
                200,
                {"status": "success", "regions": load_regions(include_inactive=True)},
            )
            return

        if path == "/admin/api/regions" and method == "POST":
            if not self.require_admin():
                return
            data = self.read_json()
            if data is None:
                self.send_json(400, {"status": "error", "message": "Invalid JSON."})
                return
            region_id = str(data.get("id", "")).strip().lower()
            if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,23}", region_id):
                self.send_json(
                    400,
                    {
                        "status": "error",
                        "message": "Server ID must be 1-24 lowercase letters, numbers, - or _.",
                    },
                )
                return
            name = str(data.get("name", "")).strip()[:60]
            if not name:
                self.send_json(400, {"status": "error", "message": "Server name is required."})
                return
            host = str(data.get("host", "")).strip()[:255]
            active = 1 if data.get("active", True) else 0
            with open_db() as conn:
                existing = conn.execute(
                    "SELECT id FROM regions WHERE id = ?", (region_id,)
                ).fetchone()
                if existing is None:
                    order = conn.execute(
                        "SELECT COALESCE(MAX(sort_order), -1) + 1 FROM regions"
                    ).fetchone()[0]
                    conn.execute(
                        "INSERT INTO regions (id, name, host, active, sort_order) "
                        "VALUES (?, ?, ?, ?, ?)",
                        (region_id, name, host, active, order),
                    )
                else:
                    conn.execute(
                        "UPDATE regions SET name = ?, host = ?, active = ? WHERE id = ?",
                        (name, host, active, region_id),
                    )
            self.send_json(
                200,
                {
                    "status": "success",
                    "region": {
                        "id": region_id,
                        "name": name,
                        "host": host,
                        "active": bool(active),
                    },
                },
            )
            return

        if path == "/admin/api/keys" and method == "GET":
            if not self.require_admin():
                return
            with open_db() as conn:
                rows = conn.execute(
                    "SELECT id, key, label, region, host, active, created_at, last_used_at, expires_at "
                    "FROM drip_keys ORDER BY id DESC"
                ).fetchall()
            keys = []
            for row in rows:
                keys.append(
                    {
                        "id": row["id"],
                        "key_masked": mask_key(row["key"]),
                        "key_tail": row["key"][-4:],
                        "label": row["label"],
                        "region": row["region"],
                        "host": row["host"],
                        "active": bool(row["active"]),
                        "created_at": row["created_at"],
                        "last_used_at": row["last_used_at"],
                        "expires_at": row["expires_at"],
                    }
                )
            self.send_json(200, {"status": "success", "keys": keys})
            return

        if path == "/admin/api/keys" and method == "POST":
            if not self.require_admin():
                return
            data = self.read_json()
            if data is None:
                self.send_json(400, {"status": "error", "message": "Invalid JSON."})
                return
            key = str(data.get("key", "")).strip()
            if not key or len(key) > 128:
                self.send_json(400, {"status": "error", "message": "Drip key is required."})
                return
            region = str(data.get("region", "all")).strip().lower() or "all"
            if region not in (region_ids(include_inactive=True) | {"all"}):
                self.send_json(400, {"status": "error", "message": "Unknown region."})
                return
            label = str(data.get("label", "")).strip()[:80]
            host = str(data.get("host", "")).strip()[:255]
            expires_at = normalize_expiry(data.get("expires_at"))
            try:
                with open_db() as conn:
                    cursor = conn.execute(
                        "INSERT INTO drip_keys (key, label, region, host, active, created_at, expires_at) "
                        "VALUES (?, ?, ?, ?, 1, ?, ?)",
                        (key, label, region, host, now_ts(), expires_at),
                    )
                    key_id = cursor.lastrowid
            except sqlite3.IntegrityError:
                self.send_json(409, {"status": "error", "message": "That key already exists."})
                return
            self.send_json(201, {"status": "success", "id": key_id})
            return

        if path == "/admin/api/keys/toggle" and method == "POST":
            if not self.require_admin():
                return
            data = self.read_json()
            if data is None:
                self.send_json(400, {"status": "error", "message": "Invalid JSON."})
                return
            try:
                key_id = int(data.get("id"))
            except (TypeError, ValueError):
                self.send_json(400, {"status": "error", "message": "Invalid key id."})
                return
            active = 1 if data.get("active") else 0
            with open_db() as conn:
                cursor = conn.execute(
                    "UPDATE drip_keys SET active = ? WHERE id = ?", (active, key_id)
                )
            if cursor.rowcount == 0:
                self.send_json(404, {"status": "error", "message": "Key not found."})
                return
            self.send_json(200, {"status": "success"})
            return

        if path == "/admin/api/keys/delete" and method == "POST":
            if not self.require_admin():
                return
            data = self.read_json()
            if data is None:
                self.send_json(400, {"status": "error", "message": "Invalid JSON."})
                return
            try:
                key_id = int(data.get("id"))
            except (TypeError, ValueError):
                self.send_json(400, {"status": "error", "message": "Invalid key id."})
                return
            with open_db() as conn:
                cursor = conn.execute("DELETE FROM drip_keys WHERE id = ?", (key_id,))
            if cursor.rowcount == 0:
                self.send_json(404, {"status": "error", "message": "Key not found."})
                return
            self.send_json(200, {"status": "success"})
            return

        if path == "/admin/api/stats" and method == "GET":
            if not self.require_admin():
                return
            with open_db() as conn:
                total = conn.execute("SELECT COUNT(*) FROM drip_keys").fetchone()[0]
                active = conn.execute(
                    "SELECT COUNT(*) FROM drip_keys WHERE active = 1"
                ).fetchone()[0]
                sessions = conn.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
                connected = conn.execute(
                    "SELECT COUNT(*) FROM sessions WHERE server IS NOT NULL"
                ).fetchone()[0]
            self.send_json(
                200,
                {
                    "status": "success",
                    "keys_total": total,
                    "keys_active": active,
                    "sessions": sessions,
                    "connected": connected,
                },
            )
            return

        self.send_json(404, {"status": "error", "message": "Not found."})

    def client_session(self):
        token = self.cookie("xitexe_session")
        if not token:
            return None
        with open_db() as conn:
            return conn.execute(
                "SELECT * FROM sessions WHERE token = ?", (token,)
            ).fetchone()

    def public_base(self):
        if PUBLIC_BASE:
            return PUBLIC_BASE
        proto = self.headers.get("X-Forwarded-Proto", "http").split(",")[0].strip()
        host = (
            self.headers.get("X-Forwarded-Host")
            or self.headers.get("Host")
            or "https://xitofcproxy.duckdns.org"
        )
        return f"{proto}://{host}"

    def pick_key(self, server):
        now = now_ts()
        with open_db() as conn:
            return conn.execute(
                "SELECT * FROM drip_keys "
                "WHERE active = 1 AND (region = ? OR region = 'all') "
                "AND (expires_at IS NULL OR expires_at = '' OR expires_at > ?) "
                "ORDER BY CASE WHEN region = ? THEN 0 ELSE 1 END, "
                "CASE WHEN last_used_at IS NULL THEN 0 ELSE 1 END, "
                "last_used_at ASC, id ASC LIMIT 1",
                (server, now, server),
            ).fetchone()

    def handle_client(self, path, method):
        if not self.gate_authed():
            self.send_json(
                401,
                {"status": "error", "code": "GATE_REQUIRED", "message": "Unlock the gate first."},
            )
            return
        if path == "/client/api/servers.php" and method == "POST":
            return self.client_servers()
        if path == "/client/api/connect.php" and method == "POST":
            return self.client_connect()
        if path == "/client/api/settings.php" and method in ("GET", "POST"):
            return self.client_settings(method)
        if path == "/client/api/session.php" and method == "GET":
            session = self.client_session()
            if session is None:
                self.send_json(200, {"status": "success", "authed": False, "servers": load_regions()})
                return
            self.send_json(
                200,
                {
                    "status": "success",
                    "authed": True,
                    "server": session["server"],
                    "expires_at": session["expires_at"],
                    "servers": load_regions(),
                },
            )
            return
        self.send_json(404, {"status": "error", "message": "Not found."})

    def client_servers(self):
        data = self.read_json()
        if data is None:
            self.send_json(400, {"status": "error", "message": "Invalid JSON."})
            return
        license_key = str(data.get("license_key", "")).strip()[:128]
        device_id = str(data.get("device_id", "")).strip()[:128]
        if not device_id:
            device_id = str(uuid.uuid4())
        gate_token = self.cookie(GATE_COOKIE) or ""
        gate_row = None
        if gate_token:
            with open_db() as conn:
                gate_row = conn.execute(
                    "SELECT license_key, key_expires_at, key_expires_unix "
                    "FROM gate_sessions WHERE token = ?",
                    (gate_token,),
                ).fetchone()
        if gate_row is not None and str(gate_row["license_key"] or "").strip():
            license_key = str(gate_row["license_key"]).strip()
        if not license_key:
            license_key = f"XITEXE-{secrets.token_hex(4).upper()}"
        token = self.cookie("xitexe_session")
        now = now_ts()
        expires_at = future_ts(SESSION_DAYS)
        with open_db() as conn:
            row = None
            if token:
                row = conn.execute(
                    "SELECT token FROM sessions WHERE token = ?", (token,)
                ).fetchone()
            if row is None:
                token = secrets.token_hex(32)
                conn.execute(
                    "INSERT INTO sessions "
                    "(token, license_key, device_id, gate_token, created_at, last_seen, expires_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (token, license_key, device_id, gate_token, now, now, expires_at),
                )
            else:
                conn.execute(
                    "UPDATE sessions SET license_key = ?, device_id = ?, gate_token = ?, "
                    "last_seen = ?, expires_at = ? WHERE token = ?",
                    (license_key, device_id, gate_token, now, expires_at, token),
                )
        self.send_json(
            200,
            {
                "status": "success",
                "expires_at": expires_at,
                "license_key": license_key,
                "key_expires_at": str(gate_row["key_expires_at"] or "") if gate_row is not None else "",
                "key_expires_unix": int(gate_row["key_expires_unix"] or 0) if gate_row is not None else 0,
                "selected_server": None,
                "servers": load_regions(),
                "profile": PROFILE,
            },
            cookies=[self.cookie_header("xitexe_session", token, SESSION_DAYS * 86400)],
        )

    def client_connect(self):
        session = self.client_session()
        if session is None:
            self.send_json(401, {"status": "error", "message": "Open a session first."})
            return
        data = self.read_json()
        if data is None:
            self.send_json(400, {"status": "error", "message": "Invalid JSON."})
            return
        server = str(data.get("server", "")).strip().lower()
        if server not in region_ids():
            self.send_json(400, {"status": "error", "message": "Unknown server."})
            return
        key = self.pick_key(server)
        if key is None:
            self.send_json(
                503,
                {
                    "status": "error",
                    "code": "NO_DRIP_KEY",
                    "message": "No active Drip key for this region. Add one in /admin.",
                },
            )
            return
        now = now_ts()
        with open_db() as conn:
            conn.execute(
                "UPDATE drip_keys SET last_used_at = ? WHERE id = ?",
                (now, key["id"]),
            )
            conn.execute(
                "UPDATE sessions SET server = ?, drip_key_id = ?, last_seen = ? WHERE token = ?",
                (server, key["id"], now, session["token"]),
            )
        host = resolve_host(server, key["host"])
        subscription_url = (
            f"{self.public_base()}/client/subscription.php?token={session['token']}"
        )
        wrapped = happ_wrap(subscription_url)
        self.send_json(
            200,
            {
                "status": "success",
                "expires_at": session["expires_at"],
                "profile": PROFILE,
                "server": server,
                "upstream": host,
                "encrypted_link": wrapped or subscription_url,
                "subscription_url": subscription_url,
                "wrapped": bool(wrapped),
            },
        )

    def client_settings(self, method):
        session = self.client_session()
        if session is None:
            self.send_json(401, {"status": "error", "message": "Open a session first."})
            return
        if method == "GET":
            with open_db() as conn:
                row = conn.execute(
                    "SELECT data FROM user_settings WHERE token = ?",
                    (session["token"],),
                ).fetchone()
            try:
                settings = json.loads(row["data"]) if row else {}
            except json.JSONDecodeError:
                settings = {}
            self.send_json(200, {"status": "success", "settings": settings})
            return
        data = self.read_json()
        if data is None or not isinstance(data.get("settings"), dict):
            self.send_json(400, {"status": "error", "message": "Invalid settings."})
            return
        payload = json.dumps(data["settings"], separators=(",", ":"))[:20000]
        with open_db() as conn:
            conn.execute(
                "INSERT INTO user_settings (token, data) VALUES (?, ?) "
                "ON CONFLICT(token) DO UPDATE SET data = excluded.data",
                (session["token"], payload),
            )
        self.send_json(200, {"status": "success"})

    def handle_panel_db(self, path, method):
        """Small Firestore-compatible JSON API backed entirely by SQLite."""
        from urllib.parse import parse_qs
        parts = [unquote(x) for x in path.split("/") if x]
        if len(parts) < 3:
            self.send_json(404, {"error": "Not found"}); return
        collection = parts[2]
        if collection not in ("keys", "config"):
            self.send_json(400, {"error": "Invalid collection"}); return
        admin = self.admin_authed()
        data = self.read_json() if method == "POST" else {}
        if method == "POST" and data is None:
            self.send_json(400, {"error": "Invalid JSON"}); return
        if method == "GET":
            action = str(parse_qs(urlsplit(self.path).query).get("action", [""])[0])
        else:
            action = str(data.get("action", "")) if isinstance(data, dict) else ""
        doc_id = parts[3] if len(parts) > 3 else str(data.get("id", ""))

        def decode(raw):
            try: return json.loads(raw or "{}")
            except Exception: return {}
        def encode(obj):
            return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
        def merge(a, b):
            for k, v in b.items():
                if "." in k:
                    parts=k.split("."); cur=a
                    for part in parts[:-1]:
                        if not isinstance(cur.get(part),dict): cur[part]={}
                        cur=cur[part]
                    if isinstance(v,dict) and v.get("__type")=="delete": cur.pop(parts[-1],None)
                    else: cur[parts[-1]]=v
                elif isinstance(v, dict) and v.get("__type")=="delete": a.pop(k,None)
                elif isinstance(v, dict) and isinstance(a.get(k), dict): merge(a[k], v)
                else: a[k] = v
            return a
        def client_key_ok(doc):
            supplied = str(self.headers.get("X-Client-Key", "")).strip().upper()
            return bool(supplied and supplied == str(doc.get("key", "")).upper())
        def clean(value):
            if isinstance(value, dict):
                if value.get("__type") == "timestamp": return {"seconds": int(value.get("seconds", 0))}
                if value.get("__type") == "serverTimestamp": return {"seconds": int(time.time())}
                if value.get("__type") == "delete": return None
                return {k: clean(v) for k,v in value.items()}
            if isinstance(value, list): return [clean(v) for v in value]
            return value

        if method == "GET":
            if action == "query":
                field = str(parse_qs(urlsplit(self.path).query).get("field", [""])[0])
                value = str(parse_qs(urlsplit(self.path).query).get("value", [""])[0])
                with open_db() as conn:
                    rows = conn.execute("SELECT doc_id,data FROM panel_docs WHERE collection_name=?", (collection,)).fetchall()
                found=[]
                for row in rows:
                    obj=decode(row["data"])
                    if str(obj.get(field, "")) == value:
                        if collection == "keys" and not admin and not (field == "key" and str(obj.get("key", "")).upper() == value.upper()) and not client_key_ok(obj): continue
                        found.append({"id":row["doc_id"],"data":obj})
                        if len(found) >= 10: break
                self.send_json(200, {"docs":found}); return
            if action == "list":
                if collection == "keys" and not admin:
                    self.send_json(401,{"error":"Admin login required"}); return
                with open_db() as conn:
                    rows=conn.execute("SELECT doc_id,data FROM panel_docs WHERE collection_name=? ORDER BY updated_at DESC",(collection,)).fetchall()
                self.send_json(200,{"docs":[{"id":r["doc_id"],"data":decode(r["data"])} for r in rows]}); return
            with open_db() as conn:
                row=conn.execute("SELECT data FROM panel_docs WHERE collection_name=? AND doc_id=?",(collection,doc_id)).fetchone()
            if row is None:
                self.send_json(200,{"exists":False,"data":{}}); return
            obj=decode(row["data"])
            if collection == "keys" and not admin and not client_key_ok(obj):
                self.send_json(403,{"error":"Forbidden"}); return
            self.send_json(200,{"exists":True,"data":obj}); return

        if method == "POST":
            if collection == "config" and not admin:
                self.send_json(401,{"error":"Admin login required"}); return
            if collection == "keys" and not admin and action not in ("update",):
                self.send_json(401,{"error":"Admin login required"}); return
            if action == "add":
                if not admin: self.send_json(401,{"error":"Admin login required"}); return
                doc_id = secrets.token_hex(10)
                obj=clean(data.get("data",{}))
                if not isinstance(obj,dict): obj={}
                with open_db() as conn:
                    conn.execute("INSERT INTO panel_docs(collection_name,doc_id,data,updated_at) VALUES(?,?,?,?)",(collection,doc_id,encode(obj),now_ts()))
                self.send_json(200,{"id":doc_id}); return
            if action in ("update","set","delete"):
                with open_db() as conn:
                    row=conn.execute("SELECT data FROM panel_docs WHERE collection_name=? AND doc_id=?",(collection,doc_id)).fetchone()
                    if action == "delete":
                        if not admin: self.send_json(401,{"error":"Admin login required"}); return
                        conn.execute("DELETE FROM panel_docs WHERE collection_name=? AND doc_id=?",(collection,doc_id))
                        self.send_json(200,{"ok":True}); return
                    if row is None and action == "update": self.send_json(404,{"error":"Document not found"}); return
                    old=decode(row["data"]) if row else {}
                    if collection == "keys" and not admin:
                        if not client_key_ok(old): self.send_json(403,{"error":"Forbidden"}); return
                        patch=clean(data.get("data",{}))
                        # Client can only update its own feature preferences and activity metadata.
                        allowed={"lastActive","lastSaved","features","hwid","hwids","status","activatedAt","expiresAt"}
                        if any(k.split(".")[0] not in allowed for k in patch):
                            self.send_json(403,{"error":"Field not allowed"}); return
                        if "status" in patch and patch["status"] != "active":
                            self.send_json(403,{"error":"Client cannot change key status"}); return
                    patch=clean(data.get("data",{}))
                    if not isinstance(patch,dict): patch={}
                    if action == "set" and not data.get("merge",False): old=patch
                    else: merge(old,patch)
                    conn.execute("INSERT INTO panel_docs(collection_name,doc_id,data,updated_at) VALUES(?,?,?,?) ON CONFLICT(collection_name,doc_id) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at",(collection,doc_id,encode(old),now_ts()))
                self.send_json(200,{"ok":True}); return
        self.send_json(405,{"error":"Method not allowed"})

    def handle_subscription(self):
        token = parse_qs(urlsplit(self.path).query).get("token", [""])[0]
        if not token:
            self.send_json(404, {"status": "error", "message": "Missing token."})
            return
        with open_db() as conn:
            session = conn.execute(
                "SELECT * FROM sessions WHERE token = ?", (token,)
            ).fetchone()
            if session is None:
                self.send_json(404, {"status": "error", "message": "Unknown token."})
                return
            gate_token = str(session["gate_token"] or "")
            gate = (
                conn.execute(
                    "SELECT * FROM gate_sessions WHERE token = ?", (gate_token,)
                ).fetchone()
                if gate_token
                else None
            )
        if (
            gate is None
            or gate["expires_at"] <= now_ts()
            or not str(gate["license_key"] or "").strip()
        ):
            if gate_token:
                self.drop_gate_session(gate_token)
            else:
                with open_db() as conn:
                    conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
                    conn.execute("DELETE FROM user_settings WHERE token = ?", (token,))
            self.send_json(
                403,
                {"status": "error", "message": "Access expired. Unlock the gate again."},
            )
            return
        valid, _, _ = self.remote_gate_check(gate["license_key"])
        if valid is not True:
            self.drop_gate_session(gate_token)
            self.send_json(
                403,
                {"status": "error", "message": "Access expired. Unlock the gate again."},
            )
            return
        with open_db() as conn:
            key = conn.execute(
                "SELECT * FROM drip_keys WHERE id = ?", (session["drip_key_id"],)
            ).fetchone()
        if key is None:
            self.send_json(404, {"status": "error", "message": "No upstream key."})
            return
        server = session["server"]
        if server not in region_ids():
            self.send_json(409, {"status": "error", "message": "Choose a server first."})
            return
        if not key["active"]:
            self.send_json(403, {"status": "error", "message": "Upstream key disabled."})
            return
        if key["expires_at"] and key["expires_at"] <= now_ts():
            self.send_json(403, {"status": "error", "message": "Upstream key expired."})
            return
        host = resolve_host(server, key["host"])
        config = {
            "remarks": PROFILE,
            "inbounds": [
                {
                    "listen": "127.0.0.1",
                    "port": 10808,
                    "protocol": "socks",
                    "settings": {"auth": "noauth", "udp": True},
                    "sniffing": {
                        "destOverride": ["http", "tls", "quic"],
                        "enabled": True,
                        "routeOnly": False,
                    },
                    "tag": "socks",
                },
                {
                    "listen": "127.0.0.1",
                    "port": 10809,
                    "protocol": "http",
                    "sniffing": {
                        "destOverride": ["http", "tls", "quic"],
                        "enabled": True,
                        "routeOnly": False,
                    },
                    "tag": "http",
                },
            ],
            "outbounds": [
                {
                    "protocol": "hysteria",
                    "settings": {"address": host, "port": 443, "version": 2},
                    "streamSettings": {
                        "hysteriaSettings": {"auth": key["key"], "version": 2},
                        "network": "hysteria",
                        "security": "tls",
                        "tlsSettings": {
                            "alpn": ["h3"],
                            "serverName": host,
                            "show": False,
                        },
                        "finalmask": {"quicParams": {"disableChromeParrot": True}},
                    },
                    "tag": "proxy",
                },
                {"protocol": "freedom", "tag": "direct"},
            ],
            "routing": {
                "domainStrategy": "AsIs",
                "rules": [
                    {"network": "tcp", "outboundTag": "proxy", "port": "39000-39999"},
                    {"network": "udp", "outboundTag": "proxy", "port": "10000-10999"},
                    {"network": "tcp,udp", "outboundTag": "direct"},
                ],
            },
        }
        self.send_json(200, config)


def main():
    init_db()
    try:
        server = Server((HOST, PORT), Handler)
    except OSError as exc:
        print(f"Could not bind {HOST}:{PORT}: {exc}", file=sys.stderr)
        return 1

    def shutdown(signum, frame):
        print(f"\nSignal {signum}: shutting down.", flush=True)
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    print(f"XITEXE running at {PUBLIC_BASE}", flush=True)
    print(f"Client:  {PUBLIC_BASE}/client/", flush=True)
    print(f"Admin:   {PUBLIC_BASE}/admin/", flush=True)
    print(f"DB:      {DB_PATH}", flush=True)
    print(f"Admin:   {'OPEN (set XITEXE_ADMIN_PASSWORD to lock)' if not ADMIN_PASSWORD else 'password protected'}", flush=True)
    if PUBLIC_BASE:
        print(f"Public:  {PUBLIC_BASE}", flush=True)

    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
