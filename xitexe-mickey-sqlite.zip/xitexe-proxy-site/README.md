# XITEXE OFC

Free Fire outfit studio. 228 outfits, live 3D preview, four build targets, and a real mod ZIP generated inside the browser.

## Run

```bash
node server.js
```

Python is dependency-free too:

```bash
python3 app.py
```

If `xitexe.py` sits next to `app.py`, `python3 app.py` automatically starts the full proxy portal. Set `XITEXE_STATIC=1` to force the static studio only.

For the studio plus the Xitexe proxy portal:

```bash
python3 xitexe.py
```

Open `https://xitofcproxy.duckdns.org`. Client portal: `https://xitofcproxy.duckdns.org/client/`. Admin: `https://xitofcproxy.duckdns.org/admin/`.

For the VPS IP directly:

```bash
./run-vps.sh
```

That binds `0.0.0.0:25565` and sets the public base to `https://xitofcproxy.duckdns.org`. Client portal: `https://xitofcproxy.duckdns.org/client/`. Admin: `https://xitofcproxy.duckdns.org/admin/`.

Environment:

| Variable | Default | Notes |
| --- | --- | --- |
| `PORT` | `25565` | HTTP port |
| `HOST` | `0.0.0.0` | Bind address |

No dependencies. Node 18+ or Python 3.10+.

## Xitexe proxy portal

`xitexe.py` serves the studio, the client portal, and the admin key pool. It mirrors the Kurama endpoint shape:

- `POST /client/api/servers.php`
- `POST /client/api/connect.php`
- `GET /client/subscription.php?token=...`
- `GET /admin` and `/admin/api/...`

The client is protected by the Xitexe key gate. The admin page is locked by default; the built-in default is `xit1009` (override with `XITEXE_ADMIN_PASSWORD`). Refreshing the admin page requires the password again.

Add one or more Drip Wire keys in `/admin`. When a client picks a region, Xitexe selects the least-recently-used active key for that region and builds the Hysteria2 subscription against `proxy-<region>.dripwire.cc:443`. The key is never sent to the browser. The portal calls Happ’s API to return `happ://crypt5`; if that call fails it returns the plain subscription URL instead.

Environment:

| Variable | Default | Notes |
| --- | --- | --- |
| `XITEXE_ADMIN_PASSWORD` | `xit1009` | Admin login password; override to change |
| `XITEXE_PUBLIC_BASE` | `https://xitofcproxy.duckdns.org` | Override for a domain/HTTPS origin |
| `XITEXE_DB` | `./xitexe.db` | SQLite key/session store |
| `XITEXE_SESSION_DAYS` | `7` | Client session lifetime |
| `XITEXE_HAPP_WRAP` | `1` | Set `0` to return plain subscriptions |

The client portal’s function switches persist per session in `user_settings`. The actual Aimbot/Freeze/ESP execution still lives in the upstream Drip Wire layer; the Xitexe subscription only carries the tunnel to it. EU and BR default hosts are unconfirmed, so use the admin “Upstream host override” if Drip uses different names there.

## Structure

```
public/
  index.html              studio UI
  css/style.css           design system
  js/social.js            version init, menu, export no-ops
  js/data.js              fflate + payload loader (split gz + export bins)
  js/app.js               catalogue, selection, worker dispatch
  js/picker.js            searchable image picker for the 7 slots
  js/preview.js           three.js live preview
  js/worker.js            LZMA bundle rebuilder (runs in a Worker)
  js/export-pool.js       worker pool + window.alokExport
  js/export-all.js        all-four-versions export
  js/package.js           final ZIP packaging + download
  assets/runtime/         274 WebP textures
  assets/item-icons/      160 item thumbnails
  assets/category-icons/  7 slot icons
  assets/previews/        generated fallback previews
  assets/brand/logo.jpg   brand logo
  alok-boot.bin           catalogue shell (26 KB gzipped)
  alok-geom.bin           meshes + mix engine + mesh index (243 KB gzipped)
  alok-base.bin           shared body geometry (164 KB gzipped)
  alok-mesh-*.bin         208 per-outfit geometry slices (~30 KB gzipped each)
  wardrobe-b6178fca57b6.gz   original payload, kept for reference
  export-f5626d75adfe-0.bin  base bundle (part 0)
  export-f5626d75adfe-1.bin  base bundle (part 1)
server.js                 zero-dependency static server
app.py                    zero-dependency Python static server
xitexe.py                 studio + client portal + admin key pool
xitexe.db                 SQLite keys, sessions, panel settings
public/client/            Xitexe client portal
public/admin/             Xitexe admin key pool
```

## Export pipeline

1. The catalogue payload loads into `window.alokWardrobe.assets`.
2. A selection maps to a `patchByVersion` entry per build target.
3. `js/export-pool.js` spins `js/worker.js`; the worker splices patched LZMA blocks into the base Unity CAB and rebuilds the bundle.
4. `js/package.js` places the `.bundle` into the Free Fire folder layout and zips it.
5. The browser downloads the ZIP directly. Nothing is uploaded.

`export-f5626d75adfe-*.bin` are served as `application/octet-stream` with a one-year immutable cache. The catalogue loads in stages:

1. `alok-boot.bin` — catalogue shell (26 KB): selectors and pickers are live as soon as this lands.
2. `alok-geom.bin` — mesh table, mix engine metadata, and the mesh-file index (243 KB).
3. `alok-base.bin` — shared body geometry for the default outfit (164 KB).
4. `alok-mesh-*.bin` — one gzipped slice per outfit, fetched only when that outfit is selected (~30 KB average, 160 KB max).

The 3D preview loads the base plus the six selected outfit slices; switching items streams just the new slice. Every piece is versioned (`?v=`), checked against its exact byte length, and re-fetched on a short or failed response before gzip decompression. Bump the version values whenever the files change so browsers pick up the new copy.

## Asset note

Runtime textures (274), item thumbnails (160), and slot icons (7) are the real WebP files pulled from the source CDN. 68 catalogue items have no thumbnail on the CDN; the picker falls back to the matching slot icon for those. The four static outfit previews still return 404 upstream, so `assets/previews/` holds generated fallbacks. Drop real preview files into the same paths to replace them; no code changes are needed.

## Export timing

The bundle rebuild runs in a browser Worker with JS LZMA. On this Android test device a full mix export took roughly 4 minutes; desktop CPUs are much faster. The UI shows progress and supports cancellation.

## Deploy

Copy the project to the server and run `python3 xitexe.py` for the portal build, or `node server.js` / `python3 app.py` for the static studio only. Keep `app.py` next to `xitexe.py`; the portal imports its static handler.

For a direct-IP VPS, run `./run-vps.sh`; it binds `0.0.0.0:25565` and sets `XITEXE_PUBLIC_BASE=https://xitofcproxy.duckdns.org`. Open TCP `25565` in the VPS firewall. For HTTPS, bind Xitexe to `127.0.0.1:25565`, put Caddy/Nginx/Cloudflare in front on `443`, and override `XITEXE_PUBLIC_BASE` with the public HTTPS origin. Only HTTP/TCP is needed on the VPS: clients connect to Drip’s Hysteria2 endpoint directly, so the VPS does not relay the Free Fire tunnel. Persist `xitexe.db`; it holds the Drip key pool and sessions. Set `XITEXE_ADMIN_PASSWORD` before exposing `/admin`.

`GET /health` returns `{ "ok": true }`.

## MICKEY custom panels (Python + SQLite, no Firebase)

The supplied MICKEY client/admin HTML panels are installed at `/client/` and `/admin/`.
Firebase SDK and project configuration have been removed. `public/panel-db.js` provides the panels' Firestore-style calls through the local `/mickey/api/` JSON API, and `xitexe.py` stores panel keys/configuration in the SQLite `panel_docs` table in `xitexe.db`.

Set `XITEXE_ADMIN_PASSWORD` to a strong secret before deployment. The admin panel authenticates against the Python server and stores a short-lived server-issued token; the old hard-coded `admin123` client-side password has been removed. Client key lookups and per-key updates are checked by the server. Keep `xitexe.db` on persistent storage and back it up.

The admin panel is available at `/admin/`; the MICKEY client panel is available at `/client/`. The separate original proxy portal client assets are overwritten by the supplied MICKEY panel. Proxy-region/subscription API routes remain in the Python backend.
